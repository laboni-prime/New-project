


$('#slder-area').slick({
    infinite: true,
    autoplay:true,
    autoplaySpeed:5000,
    arrows:false,
    dots:true,
    fade:true,
  })

 